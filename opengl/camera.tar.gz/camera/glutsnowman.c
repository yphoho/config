#include <GL/glut.h>
#include <math.h>
#include <stdlib.h>

static GLfloat xrot=0.0, yrot = 0.0;
static GLfloat eye[3]={0, 1.75, 5.0};
static GLfloat lx = 0.0f, ly = 0.0f, lz = -1.0f;
static GLint snowman_display_list;

const GLfloat toradian = 3.1415926 / 180;


void orientMe(GLfloat pitch, GLfloat yaw)
{
    lx = -cos(pitch * toradian) * sin(yaw * toradian);
    lz = -cos(pitch * toradian) * cos(yaw * toradian);
    ly = sin(pitch * toradian);

    glLoadIdentity();
    gluLookAt(eye[0], eye[1], eye[2], eye[0] + lx, eye[1] + ly, eye[2] + lz, 0.0f, 1.0f, 0.0f);
}



void moveMeFlat(int i)
{
    eye[0] = eye[0] + i * (lx) * 0.1;
    eye[2] = eye[2] + i * (lz) * 0.1;
    glLoadIdentity();
    gluLookAt(eye[0], eye[1], eye[2], eye[0] + lx, eye[1] + ly, eye[2] + lz, 0.0f, 1.0f, 0.0f);
}



void reshape(int w, int h)
{
    // Prevent a divide by zero, when window is too short
    // (you cant make a window of zero width).
    if(h == 0)
        h = 1;

    GLfloat ratio = 1.0f * w / h;
    // Reset the coordinate system before modifying
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    // Set the viewport to be the entire window
    glViewport(0, 0, w, h);
    // Set the clipping volume
    gluPerspective(45, ratio, 1, 1000);

    glMatrixMode(GL_MODELVIEW);
    orientMe(xrot, yrot);
}


void drawSnowMan()
{
    glColor3f(1.0f, 1.0f, 1.0f);

// Draw Body
    glTranslatef(0.0f, 0.75f, 0.0f);
    glutSolidSphere(0.75f, 20, 20);


// Draw Head
    glTranslatef(0.0f, 1.0f, 0.0f);
    glutSolidSphere(0.25f, 20, 20);

// Draw Eyes
    glPushMatrix();
    glColor3f(0.0f, 0.0f, 0.0f);
    glTranslatef(0.05f, 0.10f, 0.18f);
    glutSolidSphere(0.05f, 10, 10);
    glTranslatef(-0.1f, 0.0f, 0.0f);
    glutSolidSphere(0.05f, 10, 10);
    glPopMatrix();

// Draw Nose
    glColor3f(1.0f, 0.5f, 0.5f);
    glRotatef(0.0f, 1.0f, 0.0f, 0.0f);
    glutSolidCone(0.08f, 0.5f, 10, 2);
}



GLuint createDL()
{
    GLuint snowManDL;

    // Create the id for the list
    snowManDL = glGenLists(1);

    // start list
    glNewList(snowManDL, GL_COMPILE);

    // call the function that contains the rendering commands
    drawSnowMan();

    // endList
    glEndList();

    return (snowManDL);
}

void initGL()
{
    glShadeModel(GL_SMOOTH);
    glEnable(GL_DEPTH_TEST);

    snowman_display_list = createDL();
}





void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

// Draw ground
    glColor3f(0.5f, 0.5f, 0.5f);
    glBegin(GL_QUADS);
    glVertex3f(-100.0f, 0.0f, -100.0f);
    glVertex3f(-100.0f, 0.0f, 100.0f);
    glVertex3f(100.0f, 0.0f, 100.0f);
    glVertex3f(100.0f, 0.0f, -100.0f);
    glEnd();

// Draw 36 SnowMen
    for(int i = -3; i < 3; i++)
    {
        for(int j = -3; j < 3; j++)
        {
            glPushMatrix();
            glTranslatef(i * 10.0, 0, j * 10.0);
            glCallList(snowman_display_list);;
            glPopMatrix();
        }
    }
    glutSwapBuffers();
}


void processNormalKeys(unsigned char key, int x, int y)
{
    if(key == 27 || key == 'q')
        exit(0);
}


void inputKey(int key, int x, int y)
{
    switch (key)
    {
    case GLUT_KEY_LEFT:
        yrot += 2;
        orientMe(xrot, yrot);
        break;
    case GLUT_KEY_RIGHT:
        yrot -= 2;
        orientMe(xrot, yrot);
        break;

    case GLUT_KEY_PAGE_UP:
        xrot += 1;
        orientMe(xrot, yrot);
        break;
    case GLUT_KEY_PAGE_DOWN:
        xrot -= 1;
        orientMe(xrot, yrot);
        break;

    case GLUT_KEY_UP:
        moveMeFlat(2);
        break;
    case GLUT_KEY_DOWN:
        moveMeFlat(-2);
        break;
    }
}


int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);

    glutInitWindowPosition(100, 100);
    glutInitWindowSize(640, 480);
    glutCreateWindow("SnowMen from Lighthouse 3D");

    initGL();

    glutKeyboardFunc(processNormalKeys);
    glutSpecialFunc(inputKey);

    glutDisplayFunc(display);
    glutIdleFunc(display);

    glutReshapeFunc(reshape);

    glutMainLoop();

    return (0);
}
