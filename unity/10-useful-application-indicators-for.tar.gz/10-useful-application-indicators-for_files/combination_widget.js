


function dsqComboTab(tab) {
	document.getElementById('dsq-combo-people').style.display = "none";
	document.getElementById('dsq-combo-popular').style.display = "none";
	document.getElementById('dsq-combo-recent').style.display = "none";
	document.getElementById('dsq-combo-tab-people').className = "dsq-combo-tab";
	document.getElementById('dsq-combo-tab-popular').className = "dsq-combo-tab";
	document.getElementById('dsq-combo-tab-recent').className = "dsq-combo-tab";

	document.getElementById('dsq-combo-' + tab).style.display = "block";
	document.getElementById('dsq-combo-tab-' + tab).className = "dsq-combo-tab dsq-active";
}

document.write(' \
<style type="text/css" media="screen">\
	 #dsq-combo-widget ul,\
	 #dsq-combo-widget li,\
	 #dsq-combo-widget ol,\
	 #dsq-combo-widget div,\
	 #dsq-combo-widget p,\
	 #dsq-combo-widget a,\
	 #dsq-combo-widget cite,\
	 #dsq-combo-widget img {\
	 border: 0;\
	 padding: 0;\
	 margin: 0;\
	 float: none;\
	 text-indent: 0;\
	 background: none;\
	 }\
	 #dsq-combo-widget ul,\
	 #dsq-combo-widget li,\
	 #dsq-combo-widget ol {\
	 list-style-type: none;\
	 list-style-image: none;\
	 background: none;\
	 display: block;\
	 }\
	 #dsq-combo-widget #dsq-combo-content ul,\
	 #dsq-combo-widget #dsq-combo-content li,\
	 #dsq-combo-widget #dsq-combo-content ol,\
	 #dsq-combo-widget #dsq-combo-content div,\
	 #dsq-combo-widget #dsq-combo-content p,\
	 #dsq-combo-widget #dsq-combo-content a,\
	 #dsq-combo-widget #dsq-combo-content cite,\
	 #dsq-combo-widget #dsq-combo-content img {\
	 border: 0;\
	 padding: 0;\
	 margin: 0;\
	 float: none;\
	 text-indent: 0;\
	 background: none;\
	 }\
	 #dsq-combo-widget #dsq-combo-content ul,\
	 #dsq-combo-widget #dsq-combo-content li,\
	 #dsq-combo-widget #dsq-combo-content ol {\
	 list-style-type: none;\
	 list-style-image: none;\
	 background: none;\
	 display: block;\
	 }\
	 .dsq-clearfix:after {\
	 content:".";\
	 display: block;\
	 height: 0;\
	 clear: both;\
	 visibility: hidden;\
	 }\
	 /* end reset */\
	 #dsq-combo-widget { ;\
	 text-align: left;\
	 }\
	 #dsq-combo-widget #dsq-combo-tabs {\
	 float: left;\
	 }\
	 #dsq-combo-widget #dsq-combo-content {\
	 position: static;\
	 }\
	 #dsq-combo-widget #dsq-combo-content h3 {\
	 float: none;\
	 text-indent: 0;\
	 background: none;\
	 padding: 0;\
	 border: 0;\
	 margin: 0 0 10px 0;\
	 font-size: 16px;\
	 }\
	 #dsq-combo-widget #dsq-combo-tabs li {\
	 display: inline;\
	 float: left;\
	 margin-right: 2px;\
	 padding: 0px 5px;\
	 text-transform: uppercase;\
	 }\
	 #dsq-combo-widget #dsq-combo-tabs li a {\
	 text-decoration: none;\
	 font-weight: bold;\
	 font-size: 10px;\
	 }\
	 #dsq-combo-widget #dsq-combo-content .dsq-combo-box {\
	 margin: 0 0 20px;\
	 padding: 12px;\
	 clear: both;\
	 }\
	 #dsq-combo-widget #dsq-combo-content .dsq-combo-box li {\
	 padding-bottom: 10px;\
	 margin-bottom: 10px;\
	 overflow: hidden;\
	 word-wrap: break-word;\
	 }\
	 #dsq-combo-widget #dsq-combo-content .dsq-combo-avatar {\
	 float: left;\
	 height: 48px;\
	 width: 48px;\
	 margin-right: 15px;\
	 }\
	 #dsq-combo-widget #dsq-combo-content .dsq-combo-box cite {\
	 font-weight: bold;\
	 font-size: 14px;\
	 }\
	 span.dsq-widget-clout {\
	 background-color:#FF7300;\
	 color:#FFFFFF;\
	 padding:0pt 2px;\
	 }\
	 #dsq-combo-logo { text-align: right; }\
	 /* Blue */\
	 #dsq-combo-widget.blue #dsq-combo-tabs li.dsq-active { background: #E1F3FC; }\
	 #dsq-combo-widget.blue #dsq-combo-content .dsq-combo-box { background: #E1F3FC; }\
	 #dsq-combo-widget.blue #dsq-combo-tabs li { background: #B5E2FD; }\
	 #dsq-combo-widget.blue #dsq-combo-content .dsq-combo-box li { border-bottom: 1px dotted #B5E2FD; }\
	 /* Grey */\
	 #dsq-combo-widget.grey #dsq-combo-tabs li.dsq-active { background: #f0f0f0; }\
	 #dsq-combo-widget.grey #dsq-combo-content .dsq-combo-box { background: #f0f0f0; }\
	 #dsq-combo-widget.grey #dsq-combo-tabs li { background: #ccc; }\
	 #dsq-combo-widget.grey #dsq-combo-content .dsq-combo-box li { border-bottom: 1px dotted #ccc; }\
	 /* Green */\
	 #dsq-combo-widget.green #dsq-combo-tabs li.dsq-active { background: #f4ffea; }\
	 #dsq-combo-widget.green #dsq-combo-content .dsq-combo-box { background: #f4ffea; }\
	 #dsq-combo-widget.green #dsq-combo-tabs li { background: #d7edce; }\
	 #dsq-combo-widget.green #dsq-combo-content .dsq-combo-box li { border-bottom: 1px dotted #d7edce; }\
	 /* Red */\
	 #dsq-combo-widget.red #dsq-combo-tabs li.dsq-active { background: #fad8d8; }\
	 #dsq-combo-widget.red #dsq-combo-content .dsq-combo-box { background: #fad8d8; }\
	 #dsq-combo-widget.red #dsq-combo-tabs li { background: #fdb5b5; }\
	 #dsq-combo-widget.red #dsq-combo-content .dsq-combo-box li { border-bottom: 1px dotted #fdb5b5; }\
	 /* Orange */\
	 #dsq-combo-widget.orange #dsq-combo-tabs li.dsq-active { background: #fae6d8; }\
	 #dsq-combo-widget.orange #dsq-combo-content .dsq-combo-box { background: #fae6d8; }\
	 #dsq-combo-widget.orange #dsq-combo-tabs li { background: #fddfb5; }\
	 #dsq-combo-widget.orange #dsq-combo-content .dsq-combo-box li { border-bottom: 1px dotted #fddfb5; }\
	 </style>\
	 <div id="dsq-combo-widget" class="grey">\
	 <ul id="dsq-combo-tabs">\
	 <li id="dsq-combo-tab-people" ><a href="#" onclick="dsqComboTab(\'people\'); return false">People</a></li>\
	 <li id="dsq-combo-tab-recent" ><a href="#" onclick="dsqComboTab(\'recent\'); return false">Recent</a></li>\
	 <li id="dsq-combo-tab-popular" class="dsq-active"><a href="#" onclick="dsqComboTab(\'popular\'); return false">Popular</a></li>\
	 </ul>\
	 <div id="dsq-combo-content">\
	 <div id="dsq-combo-people" class="dsq-combo-box" style="display:none">\
	 <h3>Top Commenters</h3>\
	 <ul>\
	 <li class="dsq-clearfix">\
	 <a href="http://disqus.com/tinhed/">\
	 <img class="dsq-combo-avatar" src="http://mediacdn.disqus.com/uploads/users/36/8481/avatar92.jpg?1307643581">\
	 </a>\
	 <cite><a href="http://disqus.com/tinhed/">tinhed</a></cite>\
	 <div><span class="dsq-widget-clout" title="Clout: Reputation on Disqus">358</span>&nbsp;&middot;&nbsp;30 posts</div>\
	 </li>\
	 <li class="dsq-clearfix">\
	 <a href="http://disqus.com/satchitb/">\
	 <img class="dsq-combo-avatar" src="http://mediacdn.disqus.com/uploads/users/476/7896/avatar92.jpg?1289395360">\
	 </a>\
	 <cite><a href="http://disqus.com/satchitb/">satchitb</a></cite>\
	 <div><span class="dsq-widget-clout" title="Clout: Reputation on Disqus">1703</span>&nbsp;&middot;&nbsp;26 posts</div>\
	 </li>\
	 <li class="dsq-clearfix">\
	 <a href="http://disqus.com/madjr/">\
	 <img class="dsq-combo-avatar" src="http://mediacdn.disqus.com/1308681305/images/noavatar92.png">\
	 </a>\
	 <cite><a href="http://disqus.com/madjr/">madjr</a></cite>\
	 <div><span class="dsq-widget-clout" title="Clout: Reputation on Disqus">2447</span>&nbsp;&middot;&nbsp;23 posts</div>\
	 </li>\
	 <li class="dsq-clearfix">\
	 <a href="http://disqus.com/musl1m/">\
	 <img class="dsq-combo-avatar" src="http://mediacdn.disqus.com/1308681305/images/noavatar92.png">\
	 </a>\
	 <cite><a href="http://disqus.com/musl1m/">musl1m</a></cite>\
	 <div><span class="dsq-widget-clout" title="Clout: Reputation on Disqus">359</span>&nbsp;&middot;&nbsp;17 posts</div>\
	 </li>\
	 <li class="dsq-clearfix">\
	 <a href="http://disqus.com/SeanW1972/">\
	 <img class="dsq-combo-avatar" src="http://mediacdn.disqus.com/uploads/users/329/5964/avatar92.jpg?1300735816">\
	 </a>\
	 <cite><a href="http://disqus.com/SeanW1972/">Sean</a></cite>\
	 <div><span class="dsq-widget-clout" title="Clout: Reputation on Disqus">440</span>&nbsp;&middot;&nbsp;15 posts</div>\
	 </li>\
	 <li class="dsq-clearfix">\
	 <a href="http://disqus.com/openid-56015/">\
	 <img class="dsq-combo-avatar" src="http://mediacdn.disqus.com/uploads/users/627/6293/avatar92.jpg?1305200827">\
	 </a>\
	 <cite><a href="http://disqus.com/openid-56015/">Prashanth</a></cite>\
	 <div><span class="dsq-widget-clout" title="Clout: Reputation on Disqus">61</span>&nbsp;&middot;&nbsp;13 posts</div>\
	 </li>\
	 </ul>\
	 <div id="dsq-combo-logo"><a href="http://disqus.com"><img src="http://mediacdn.disqus.com/1308681305/images/embed/widget-logo.png"></a></div>\
	 </div>\
	 <div id="dsq-combo-recent" class="dsq-combo-box" style="display:none">\
	 <h3>Recent Comments</h3>\
	 <ul>\
	 <li class="dsq-clearfix">\
	 <a href="http://disqus.com/guest/10a1604977874453da9223b31ab40838/"><img class="dsq-combo-avatar" src="http://mediacdn.disqus.com/1308681305/images/noavatar92.png"></a>\
	 <a class="dsq-widget-user dsq-unregistered-user" href="http://disqus.com/guest/10a1604977874453da9223b31ab40838/">Buckeyered80</a>\
	 <span class="dsq-widget-comment">And you lost your freedom.</span>\
	 <p class="dsq-widget-meta"><a href="http://www.techdrivein.com/2011/04/12-things-i-did-after-installing-new.html">12 Things I did After Installing New Ubuntu 11.04 &quot;Natty Narwhal&quot;</a>&nbsp;&middot;&nbsp;<a href="http://www.techdrivein.com/2011/04/12-things-i-did-after-installing-new.html#comment-231536278">11 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-clearfix">\
	 <a href="http://disqus.com/guest/5c98f87dd412f20d4313ffe2af8a77a0/"><img class="dsq-combo-avatar" src="http://mediacdn.disqus.com/1308681305/images/noavatar92.png"></a>\
	 <a class="dsq-widget-user dsq-unregistered-user" href="http://disqus.com/guest/5c98f87dd412f20d4313ffe2af8a77a0/">Imrmobile</a>\
	 <span class="dsq-widget-comment">Like? I am in the market for a good todo manager, tell me your secrets...</span>\
	 <p class="dsq-widget-meta"><a href="http://www.techdrivein.com/2010/11/12-open-source-android-applications.html">12 Open Source Android Applications Worth Checking Out</a>&nbsp;&middot;&nbsp;<a href="http://www.techdrivein.com/2010/11/12-open-source-android-applications.html#comment-231486350">47 minutes ago</a></p>\
	 </li>\
	 <li class="dsq-clearfix">\
	 <a href="http://disqus.com/guest/25b84791a6b462b11fce8ab2762b43cb/"><img class="dsq-combo-avatar" src="http://mediacdn.disqus.com/1308681305/images/noavatar92.png"></a>\
	 <a class="dsq-widget-user dsq-unregistered-user" href="http://disqus.com/guest/25b84791a6b462b11fce8ab2762b43cb/">Geri Negrete</a>\
	 <span class="dsq-widget-comment">yeah, It\'s Awesome thing. From lot\'s of days i uses ubuntu but i don\'t have idea to active Unity Grab Handles. Thanks for providing such wonderful information. Is you have another such kind of...</span>\
	 <p class="dsq-widget-meta"><a href="http://www.techdrivein.com/2011/06/unity-grab-handles-are-beautiful-learn.html">Unity Grab Handles Are Beautiful, Learn How to Enable it in Ubuntu 11.04 Natty Narwhal</a>&nbsp;&middot;&nbsp;<a href="http://www.techdrivein.com/2011/06/unity-grab-handles-are-beautiful-learn.html#comment-231311524">5 hours ago</a></p>\
	 </li>\
	 <li class="dsq-clearfix">\
	 <a href="http://disqus.com/google-5c808af3bb78a27ecc7ad327a5f3bd58/"><img class="dsq-combo-avatar" src="http://mediacdn.disqus.com/1308681305/images/noavatar92.png"></a>\
	 <a class="dsq-widget-user" href="http://disqus.com/google-5c808af3bb78a27ecc7ad327a5f3bd58/">Grey Geek</a>\
	 <span class="dsq-widget-comment">These tweet "comments" really stink up the comment section with useless trash. They are just like spam or ad bots posting retail items and prices. Perhaps they could be automatically hidden since...</span>\
	 <p class="dsq-widget-meta"><a href="http://www.techdrivein.com/2011/06/ad-bard-advertising-network-serving.html">Ad Bard, The Advertising Network Serving FOSS Only Ads, is Shutting Down</a>&nbsp;&middot;&nbsp;<a href="http://www.techdrivein.com/2011/06/ad-bard-advertising-network-serving.html#comment-231311299">5 hours ago</a></p>\
	 </li>\
	 <li class="dsq-clearfix">\
	 <a href="http://disqus.com/guest/301817725d79f38c673b578f14cbac50/"><img class="dsq-combo-avatar" src="http://mediacdn.disqus.com/1308681305/images/noavatar92.png"></a>\
	 <a class="dsq-widget-user dsq-unregistered-user" href="http://disqus.com/guest/301817725d79f38c673b578f14cbac50/">dgrb</a>\
	 <span class="dsq-widget-comment">Is it my imagination, or are these \'grab handles\' pretty much the same as the \'halo\' available in smalltalk environments - since 1980 or so...<br></span>\
	 <p class="dsq-widget-meta"><a href="http://www.techdrivein.com/2011/06/unity-grab-handles-are-beautiful-learn.html">Unity Grab Handles Are Beautiful, Learn How to Enable it in Ubuntu 11.04 Natty Narwhal</a>&nbsp;&middot;&nbsp;<a href="http://www.techdrivein.com/2011/06/unity-grab-handles-are-beautiful-learn.html#comment-231227242">8 hours ago</a></p>\
	 </li>\
	 <li class="dsq-clearfix">\
	 <a href="http://disqus.com/sureshpeters/"><img class="dsq-combo-avatar" src="http://mediacdn.disqus.com/uploads/users/246/4966/avatar92.jpg?1308680843"></a>\
	 <a class="dsq-widget-user" href="http://disqus.com/sureshpeters/">sureshpeters @software buzzer</a>\
	 <span class="dsq-widget-comment">the firefox latest version 5.0 is available for download now . the firefox is faster and smarter now better UI ,its available for windows, mac, linux too and it has multi language support here is...</span>\
	 <p class="dsq-widget-meta"><a href="http://www.techdrivein.com/2010/07/tab-candy-new-firefox-40-innovation.html">Tab Candy - New Firefox 4.0 Innovation That Has Every Potential To Become an Industry Standard</a>&nbsp;&middot;&nbsp;<a href="http://www.techdrivein.com/2010/07/tab-candy-new-firefox-40-innovation.html#comment-231222528">8 hours ago</a></p>\
	 </li>\
	 </ul>\
	 <div id="dsq-combo-logo"><a href="http://disqus.com"><img src="http://mediacdn.disqus.com/1308681305/images/embed/widget-logo.png"></a></div>\
	 </div>\
	 <div id="dsq-combo-popular" class="dsq-combo-box" >\
	 <h3>Most Discussed</h3>\
	 <ul>\
	 <li class="dsq-clearfix">\
	 <a class="dsq-widget-thread" href="http://www.techdrivein.com/2011/06/unity-grab-handles-are-beautiful-learn.html">Unity Grab Handles Are Beautiful, Learn How to Enable it in Ubuntu 11.04 Natty Narwhal</a>\
	 <p class="dsq-widget-meta">4 comments &middot; 5 hours ago</p>\
	 </li>\
	 <li class="dsq-clearfix">\
	 <a class="dsq-widget-thread" href="http://www.techdrivein.com/2011/06/ad-bard-advertising-network-serving.html">Ad Bard, The Advertising Network Serving FOSS Only Ads, is Shutting Down</a>\
	 <p class="dsq-widget-meta">2 comments &middot; 5 hours ago</p>\
	 </li>\
	 <li class="dsq-clearfix">\
	 <a class="dsq-widget-thread" href="http://www.techdrivein.com/2011/06/termkit-is-terminal-reimagined-install.html">TermKit is Terminal Reimagined, Install TermKit in Ubuntu 11.04 Easily</a>\
	 <p class="dsq-widget-meta">17 comments &middot; 20 hours ago</p>\
	 </li>\
	 <li class="dsq-clearfix">\
	 <a class="dsq-widget-thread" href="http://www.techdrivein.com/2011/06/15-best-android-apps-for-travelers.html">15 Best Android Apps for Travelers Among You</a>\
	 <p class="dsq-widget-meta">4 comments &middot; 1 day ago</p>\
	 </li>\
	 <li class="dsq-clearfix">\
	 <a class="dsq-widget-thread" href="http://www.techdrivein.com/2011/05/canonical-and-ubuntu-needs-to-settle.html">Canonical and Ubuntu Needs to Settle Down</a>\
	 <p class="dsq-widget-meta">54 comments &middot; 2 weeks ago</p>\
	 </li>\
	 <li class="dsq-clearfix">\
	 <a class="dsq-widget-thread" href="http://www.techdrivein.com/2011/06/google-chrome-growing-at-breakneck.html">Google Chrome Growing at Breakneck Speed, Firefox May Lose #2 Spot Sooner Than You Think</a>\
	 <p class="dsq-widget-meta">17 comments &middot; 1 week ago</p>\
	 </li>\
	 </ul>\
	 <div id="dsq-combo-logo"><a href="http://disqus.com"><img src="http://mediacdn.disqus.com/1308681305/images/embed/widget-logo.png"></a></div>\
	 </div>\
	 </div>\
	 </div>\
');
